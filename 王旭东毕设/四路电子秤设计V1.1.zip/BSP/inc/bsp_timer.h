#ifndef _BSP_TIMER_H
#define _BSP_TIMER_H

#include "inc.h"


void Timer0Init(void);


#endif