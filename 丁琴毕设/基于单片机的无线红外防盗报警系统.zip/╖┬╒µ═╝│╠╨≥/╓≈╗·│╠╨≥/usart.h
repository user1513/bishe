#ifndef _USART_H
#define _USART_H

#include "app.h"

void uart_init();



#endif