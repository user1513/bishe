#ifndef _KEY_H
#define _KEY_H

#include "app.h"

sbit key1 = P2^7;

uint8_t kscanf(void);

void Delay5ms();		//@11.0592MHz



#endif