#ifndef _TIMER_H
#define _TIMER_H

#include "app.h"


void Timer0Init(void);


#endif