
#ifndef _TIMEFILE_H__
#define _TIMEFILE_H__


//extern bit bTime_50Ms;
extern bit bTime_500Ms;
extern bit time_1000ms;

void InitTimer(void);


#endif





